# noraneko42A

A 42-key keyboard with per-key RGB lighting, powered by the RP2040 and supporting Vial.

* Keyboard Maintainer: [Daraku-Neko](https://github.com/Daraku-Neko)
* Hardware Supported: noraneko42A PCB (RP2040)

Make example for this keyboard (after setting up your [vial-qmk](https://github.com/vial-kb/vial-qmk) build environment):

    make noraneko42a:vial

The firmware is built as `noraneko42a_vial.uf2`.

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).

## Bootloader

Enter the bootloader in 3 ways:

* **Bootmagic reset**: Hold down the key at (0,0) in the matrix (the top left key, Escape) and plug in the keyboard
* **BOOT button**: Hold down the BOOT button on the PCB and plug in the keyboard
* **Keycode in layout**: Press the key mapped to `QK_BOOT` (layer 3 in the default Vial keymap)

In bootloader mode the keyboard shows up as a USB drive named `RPI-RP2`. Copy the `.uf2` file onto it to flash; the keyboard reboots automatically.
